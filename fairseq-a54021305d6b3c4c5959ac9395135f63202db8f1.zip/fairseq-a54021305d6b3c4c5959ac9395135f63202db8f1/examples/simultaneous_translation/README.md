# Simultaneous Translation
Examples of simultaneous translation in fairseq
- [English-to-Japanese text-to-text wait-k model](docs/enja-waitk.md)
- [English-to-Germen text-to-text monotonic multihead attention model](docs/ende-mma.md)
- [English-to-Germen speech-to-text simultaneous translation model](../speech_to_text/docs/simulst_mustc_example.md)
